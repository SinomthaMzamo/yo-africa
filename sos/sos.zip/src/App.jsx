import { useState } from 'react'
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'

import Login from './Login.jsx'
import NavBar from './NavBar.jsx'
import Footer from './Footer.jsx'


function App() {
  const feature = "services";
  const features = ["library", "locator", "symptom tracker"];

  const page = {
    backgroundColor: '#2d5b3e',
    display: 'flex',
    flexDirection: 'column',
    gap: '1em',
  }


  return (
    <div style={page}>
      <NavBar feature={feature} features={features}/>
      <Login/>
      <Footer/>
    </div>
  )
}

export default App
